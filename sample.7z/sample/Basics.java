package sample.sample;

public class Basics {

	public static void main(String[] args) {
		//JDK is a combination of Both JDK+JRE;; 
		
		// If you want to develop and run java program we must need to have JDK
		// If you want to run java program we need ONLY JRE
		
		
		// JRE consist of JVM(which is responsible for running code line by line) 
		// Java is platform dependent. JVM Is platform IN-Dependent
		
		// Why JVM Is platform independent.?
	
		/*The JVM is used to both translate the bytecode into the machine language for a particular computer, 
		and actually execute the corresponding machine-language instructions as well. The JVM and bytecode combined give Java its status as a "portable" language.
	*/
		
	}

}
