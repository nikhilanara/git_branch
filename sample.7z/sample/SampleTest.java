package sample.sample;

public class SampleTest {

	public static void main(String[] args) {
	}

}
